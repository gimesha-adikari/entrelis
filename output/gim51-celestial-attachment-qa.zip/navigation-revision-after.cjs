const fs = require('node:fs');
const qa = require('./qa-common.cjs');
const result = {
  label: 'Exact-progress production navigation continuity, Chromium / SwiftShader',
  clockDurationMs: 420,
  forwardReverseSequence: [],
  interruptedTransitions: [],
  consoleErrors: [],
};
const sequence = ['ownership','memory','stack-and-heap','operating-systems','cpus','operating-systems','stack-and-heap','memory','ownership','rust'];

async function trigger(page, slug) {
  await page.evaluate((slug) => {
    const control = document.querySelector(`[data-concept-slug="${slug}"]`);
    if (control) {
      const key = Object.keys(control).find((name) => name.startsWith('__reactProps$'));
      control[key]?.onClick?.();
    } else {
      history.pushState({ slug }, '', `/concept/${slug}`);
      dispatchEvent(new PopStateEvent('popstate'));
    }
    window.__gim51NavigationStart = performance.now();
  }, slug);
  await page.waitForFunction(({ expression, slug }) => {
    const snapshot = eval(expression);
    return snapshot?.travel?.active === true && snapshot.travel.toSlug === slug;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, slug }, { timeout: 10000 });
}
async function stepToProgress(page, progress) {
  await page.evaluate(({ progress, duration }) => {
    window.__gim51QAClock.fakeOrigin = window.__gim51NavigationStart + progress * duration;
  }, { progress, duration: result.clockDurationMs });
  await page.waitForFunction(({ expression, progress }) => {
    const snapshot = eval(expression);
    return Math.abs((snapshot?.travel?.progress ?? -1) - progress) < 1e-9;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, progress }, { timeout: 10000 });
}
async function waitForTarget(page, slug) {
  await page.waitForFunction(({ expression, slug }) => {
    const snapshot = eval(expression);
    return location.pathname.endsWith(`/concept/${slug}`) && snapshot?.scene?.focus?.slug === slug && snapshot?.travel?.active === false && snapshot?.travel?.progress === 1;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, slug }, { timeout: 10000 });
}
async function sampleAttachment(page) {
  const snapshot = await qa.getSnapshot(page);
  const diagnostics = await qa.getDiagnostics(page);
  return {
    snapshot,
    attachment: qa.analyzeAttachments(snapshot, diagnostics.pathCommands, diagnostics.bodyCircles),
  };
}

(async () => {
  const browser = await qa.launchBrowser();
  try {
    const { context, page } = await qa.createPage(browser, {
      viewport: { width: 1440, height: 900 },
      deviceScaleFactor: 1,
      slowTransitionClock: true,
      clockScale: 0,
    });
    page.on('console', (message) => { if (message.type() === 'error') result.consoleErrors.push(message.text()); });
    page.on('pageerror', (error) => result.consoleErrors.push(error.message));
    await qa.openFocus(page, 'rust');

    for (let index = 0; index < sequence.length; index += 1) {
      const from = index === 0 ? 'rust' : sequence[index - 1];
      const to = sequence[index];
      const zoom = [0.3, 0.6, 1, 3][index % 4];
      await trigger(page, to);
      await page.evaluate(({ expression, zoom }) => { eval(expression).transform.k = zoom; }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, zoom });
      await stepToProgress(page, 0.5);
      const { snapshot, attachment } = await sampleAttachment(page);
      result.forwardReverseSequence.push({
        index: index + 1,
        from,
        to,
        zoom,
        progress: snapshot.travel.progress,
        sameDisplayedScene: snapshot.sameDisplayedScene,
        focus: snapshot.scene.focus.slug,
        attachment,
      });
      await stepToProgress(page, 1);
      await waitForTarget(page, to);
    }

    await trigger(page, 'ownership');
    await stepToProgress(page, 0.5);
    const firstMidpoint = (await sampleAttachment(page)).snapshot;
    await trigger(page, 'memory');
    await page.evaluate((expression) => { eval(expression).transform.k = 0.3; }, qa.GRAPH_SNAPSHOT_EXPRESSION);
    await stepToProgress(page, 0.25);
    const firstInterruption = await sampleAttachment(page);
    result.interruptedTransitions.push({
      phase: 'ownership-to-memory-interruption',
      firstTransitionProgress: firstMidpoint.travel.progress,
      zoom: firstInterruption.snapshot.transform.k,
      replacementTransitionProgress: firstInterruption.snapshot.travel.progress,
      replacementTarget: firstInterruption.snapshot.travel.toSlug,
      currentFocus: firstInterruption.snapshot.scene.focus.slug,
      sameDisplayedScene: firstInterruption.snapshot.sameDisplayedScene,
      attachment: firstInterruption.attachment,
    });

    await trigger(page, 'stack-and-heap');
    await page.evaluate((expression) => { eval(expression).transform.k = 3; }, qa.GRAPH_SNAPSHOT_EXPRESSION);
    await stepToProgress(page, 0.25);
    const secondInterruption = await sampleAttachment(page);
    result.interruptedTransitions.push({
      phase: 'memory-to-stack-and-heap-interruption',
      replacementTransitionProgress: secondInterruption.snapshot.travel.progress,
      zoom: secondInterruption.snapshot.transform.k,
      replacementTarget: secondInterruption.snapshot.travel.toSlug,
      currentFocus: secondInterruption.snapshot.scene.focus.slug,
      sameDisplayedScene: secondInterruption.snapshot.sameDisplayedScene,
      attachment: secondInterruption.attachment,
    });
    await stepToProgress(page, 1);
    await waitForTarget(page, 'stack-and-heap');
    const final = await qa.getSnapshot(page);
    result.finalSnapshot = {
      focus: final.scene.focus.slug,
      transform: final.transform,
      viewport: final.viewport,
      sameDisplayedScene: final.sameDisplayedScene,
    };
    await context.close();
  } finally {
    await browser.close();
  }
  fs.writeFileSync('/workspace/gim51-qa/revision-after/navigation.json', JSON.stringify(result, null, 2));
  console.log(JSON.stringify({
    sequence: result.forwardReverseSequence.map(({ from, to, zoom, progress, sameDisplayedScene, attachment }) => ({ from, to, zoom, progress, sameDisplayedScene, attachment })),
    interruptedTransitions: result.interruptedTransitions,
    finalSnapshot: result.finalSnapshot,
    consoleErrors: result.consoleErrors,
  }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
