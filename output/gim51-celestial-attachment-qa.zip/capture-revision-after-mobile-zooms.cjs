const fs = require('node:fs');
const path = require('node:path');
const qa = require('./qa-common.cjs');
const outputDir = '/workspace/gim51-qa/revision-after';
const captures = [];

(async () => {
  const browser = await qa.launchBrowser();
  try {
    for (const entry of [
      { viewport: { width: 390, height: 844 }, dpr: 3, slug: 'stack-and-heap' },
      { viewport: { width: 320, height: 700 }, dpr: 2, slug: 'operating-systems' },
    ]) {
      const { context, page } = await qa.createPage(browser, {
        viewport: entry.viewport,
        deviceScaleFactor: entry.dpr,
        isMobile: true,
        hasTouch: true,
      });
      try {
        await qa.openFocus(page, entry.slug);
        for (const zoom of [0.3, 0.6, 1, 3]) {
          await qa.setZoom(page, zoom);
          const snapshot = await qa.getSnapshot(page);
          const dprLabel = String(entry.dpr).replace('.', 'p');
          const name = `mobile-${entry.viewport.width}x${entry.viewport.height}-${entry.slug}-k${zoom}-dpr${dprLabel}.png`;
          await page.screenshot({ path: path.join(outputDir, name) });
          captures.push({ name, slug: entry.slug, zoom, viewport: snapshot.viewport, canvas: snapshot.canvas, productionCanvas: snapshot.productionCanvas, sameDisplayedScene: snapshot.sameDisplayedScene });
        }
      } finally {
        await context.close();
      }
    }
  } finally {
    await browser.close();
  }
  fs.writeFileSync(path.join(outputDir, 'mobile-zoom-metadata.json'), JSON.stringify(captures, null, 2));
  console.log(JSON.stringify(captures.map(({ name, viewport, canvas }) => ({ name, viewport, graphCanvas: canvas.rect })), null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
