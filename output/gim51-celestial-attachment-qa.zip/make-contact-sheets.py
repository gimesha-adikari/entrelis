from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/workspace/gim51-qa')
ZOOMS = ['0.3', '0.6', '1', '3']
SLUGS = ['rust', 'ownership', 'stack-and-heap', 'operating-systems']
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
thumb_w, thumb_h = 480, 300
margin, label_h = 14, 28

for slug in SLUGS:
    sheet = Image.new('RGB', (margin * 3 + thumb_w * 2, margin + (thumb_h + label_h) * 4), '#101522')
    draw = ImageDraw.Draw(sheet)
    for row, zoom in enumerate(ZOOMS):
        y = margin + row * (thumb_h + label_h)
        draw.text((margin, y), f'{slug}  k={zoom}', font=font, fill='#ffffff')
        y_img = y + label_h
        for col, phase in enumerate(['before', 'after']):
            file = ROOT / phase / f'{slug}-k{zoom}-dpr1.png'
            image = Image.open(file).convert('RGB')
            image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
            x = margin + col * (thumb_w + margin)
            draw.text((x, y_img - 18), phase.upper(), font=small, fill='#8bd5ff')
            sheet.paste(image, (x, y_img))
    sheet.save(ROOT / f'comparison-{slug}.jpg', quality=92)

for phase in ['before', 'after']:
    thumb_w, thumb_h = 260, 163
    label_h = 25
    sheet = Image.new('RGB', (4 * thumb_w, 4 * (thumb_h + label_h)), '#101522')
    draw = ImageDraw.Draw(sheet)
    for row, slug in enumerate(SLUGS):
        for col, zoom in enumerate(ZOOMS):
            y = row * (thumb_h + label_h)
            x = col * thumb_w
            draw.text((x + 8, y + 4), f'{slug}  k={zoom}', font=small, fill='#ffffff')
            image = Image.open(ROOT / phase / f'{slug}-k{zoom}-dpr1.png').convert('RGB')
            image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
            sheet.paste(image, (x, y + label_h))
    sheet.save(ROOT / phase / 'contact-sheet.png')

files = [ROOT / 'after' / f'transition-rust-to-ownership-p{pct}.png' for pct in [0, 25, 50, 75, 100]]
thumb_w, thumb_h = 350, 219
sheet = Image.new('RGB', (5 * thumb_w, thumb_h + 34), '#101522')
draw = ImageDraw.Draw(sheet)
for index, (pct, file) in enumerate(zip([0, 25, 50, 75, 100], files)):
    draw.text((index * thumb_w + 8, 4), f'{pct}%', font=font, fill='#ffffff')
    image = Image.open(file).convert('RGB')
    image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
    sheet.paste(image, (index * thumb_w, 34))
sheet.save(ROOT / 'transition-rust-ownership.jpg', quality=92)
