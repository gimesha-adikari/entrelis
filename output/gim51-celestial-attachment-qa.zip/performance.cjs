const fs = require('node:fs');
const qa = require('./qa-common.cjs');
const output = { label: 'Chromium production build using SwiftShader; timings are cloud/software-rendered and are not hardware-GPU claims', coldTransitions: [], warmCycles: [], warmAggregate: null, environment: null };
const statKeys = [
  'activeEntries','warmEntries','pendingEntries','preparingEntries','renderFrameCount','renderCalls','triangles','geometries','textures',
  'warmHits','warmMisses','warmParks','warmEvictions','bodyCreates','bodyCreateTotalMs','bodyDisposals','identityReplacements',
  'shaderPreparationsStarted','shaderPreparationsCompleted','shaderPreparationCancellations','shaderPreparationFailures',
  'shaderPreparationSetupTotalMs','shaderPreparationSetupMaxMs','shaderPreparationWaitTotalMs','controllerUpdateCount',
  'controllerUpdateTotalMs','controllerUpdateMaxMs','rendererCallTotalMs','rendererCallMaxMs'
];
const navigation = ['ownership','memory','stack-and-heap','operating-systems','cpus','operating-systems','stack-and-heap','memory','ownership','rust'];

function counterDelta(before, after) {
  const result = {};
  for (const key of statKeys) {
    if (typeof before?.[key] === 'number' && typeof after?.[key] === 'number') result[key] = after[key] - before[key];
  }
  return result;
}
function statsSnapshot(stats) {
  const result = {};
  for (const key of statKeys) if (typeof stats?.[key] === 'number' || typeof stats?.[key] === 'boolean') result[key] = stats[key];
  return result;
}
async function triggerTransition(page, slug) {
  await page.evaluate((slug) => {
    const control = document.querySelector(`[data-concept-slug="${slug}"]`);
    if (control) {
      const propsKey = Object.keys(control).find((key) => key.startsWith('__reactProps$'));
      control[propsKey]?.onClick?.();
    } else {
      const url = `/concept/${slug}`;
      window.history.pushState({ slug }, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  }, slug);
}
async function sampleTransition(page, from, to, cycle) {
  await triggerTransition(page, to);
  await page.waitForFunction(({ expression, to }) => {
    const snapshot = eval(expression);
    return snapshot?.travel?.active === false && snapshot?.travel?.progress === 1 && snapshot?.scene?.focus?.slug === to;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, to }, { timeout: 10000 });
  const snapshot = await qa.getSnapshot(page);
  const diagnostics = await qa.getDiagnostics(page);
  const attachment = qa.analyzeAttachments(snapshot, diagnostics.pathCommands, diagnostics.bodyCircles);
  return {
    cycle, from, to, phase: 'settled', progress: snapshot.travel?.progress, sameDisplayedScene: snapshot.sameDisplayedScene,
    endpointAttachment: attachment, focus: snapshot.scene.focus.slug,
  };
}
async function waitForSettledTarget(page, slug) {
  await page.waitForFunction(({ expression, slug }) => {
    const snapshot = eval(expression);
    return location.pathname.endsWith(`/concept/${slug}`) && snapshot?.travel?.active === false && snapshot?.travel?.progress === 1 && snapshot?.scene?.focus?.slug === slug;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, slug }, { timeout: 10000 });
}

(async () => {
  const browser = await qa.launchBrowser();
  try {
    const coldTests = [
      { from: 'rust', to: 'cpus' },
      { from: 'rust', to: 'transistors' },
      { from: 'ownership', to: 'cpus' },
      { from: 'ownership', to: 'transistors' },
    ];
    for (let index = 0; index < coldTests.length; index += 1) {
      const test = coldTests[index];
      const { context, page } = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
      try {
        await qa.openFocus(page, test.from);
        const before = await qa.getSnapshot(page);
        const targetPresent = before.scene.allNodes.some((node) => node.slug === test.to);
        const beforeStats = statsSnapshot(before.controllerStats);
        await qa.clearDiagnostics(page);
        const startedAt = Date.now();
        await triggerTransition(page, test.to);
        await waitForSettledTarget(page, test.to);
        const wallMs = Date.now() - startedAt;
        await page.waitForTimeout(100);
        const after = await qa.getSnapshot(page);
        const diagnostics = await qa.getDiagnostics(page);
        output.coldTransitions.push({
          ...test, coldRun: index + 1, initialTargetInScene: targetPresent, elapsedWallMs: wallMs,
          initialCounters: beforeStats, finalCounters: statsSnapshot(after.controllerStats),
          counterDelta: counterDelta(beforeStats, after.controllerStats), diagnostics,
          environment: { viewport: after.viewport, renderer: after.productionCanvas?.renderer, canvas: after.productionCanvas },
        });
      } finally { await context.close(); }
    }

    const { context, page } = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    try {
      await qa.openFocus(page, 'rust');
      for (const slug of navigation) {
        await triggerTransition(page, slug);
        await waitForSettledTarget(page, slug);
      }
      const warmBase = await qa.getSnapshot(page);
      const warmBaselineStats = statsSnapshot(warmBase.controllerStats);
      await qa.clearDiagnostics(page);
      for (let cycle = 1; cycle <= 3; cycle += 1) {
        const transitions = [];
        let from = 'rust';
        for (const to of navigation) {
          transitions.push(await sampleTransition(page, from, to, cycle));
          from = to;
        }
        output.warmCycles.push({ cycle, transitions });
      }
      const warmFinal = await qa.getSnapshot(page);
      const warmDiagnostics = await qa.getDiagnostics(page);
      output.warmAggregate = {
        baselineCounters: warmBaselineStats,
        finalCounters: statsSnapshot(warmFinal.controllerStats),
        counterDelta: counterDelta(warmBaselineStats, warmFinal.controllerStats),
        diagnostics: {
          ...qa.aggregateDiagnostics([{ diagnostics: warmDiagnostics }]),
          resources: warmDiagnostics.resources,
          pathCommandCount: warmDiagnostics.pathCommands.length,
          perTransitionSamples: output.warmCycles.flatMap((cycle) => cycle.transitions.map((transition) => transition.endpointAttachment)),
        },
        environment: { viewport: warmFinal.viewport, renderer: warmFinal.productionCanvas?.renderer, canvas: warmFinal.productionCanvas },
      };
      output.environment = {
        viewport: warmFinal.viewport, userAgent: warmFinal.userAgent,
        renderer: warmFinal.productionCanvas?.renderer, reducedMotion: warmFinal.reducedMotion,
      };
    } finally { await context.close(); }
  } finally { await browser.close(); }
  fs.writeFileSync('/workspace/gim51-qa/performance.json', JSON.stringify(output, null, 2));
  console.log(JSON.stringify({
    environment: output.environment,
    cold: output.coldTransitions.map((run) => ({ from: run.from, to: run.to, initialTargetInScene: run.initialTargetInScene, elapsedWallMs: run.elapsedWallMs, counterDelta: run.counterDelta, frames: qa.summarizeFrames(run.diagnostics.frameIntervalsMs), draws: qa.summarizeNumbers(run.diagnostics.canvasDrawMs), longTasks: run.diagnostics.longTasks.length, resources: run.diagnostics.resources })),
    warm: output.warmAggregate && { cycles: output.warmCycles.length, transitionCount: output.warmCycles.reduce((sum, cycle) => sum + cycle.transitions.length, 0), counterDelta: output.warmAggregate.counterDelta, diagnostics: output.warmAggregate.diagnostics, attachmentSamples: output.warmCycles.flatMap((cycle) => cycle.transitions.map((item) => item.endpointAttachment)).filter((item) => item.pathCount > 0).length },
  }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
