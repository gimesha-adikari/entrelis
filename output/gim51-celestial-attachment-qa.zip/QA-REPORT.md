# GIM-51 — Celestial-Surface Connection Anchoring

## Revision and workspace

- Starting revision: `40969c43004d792c0f18658ccd97fbb632bdb967` on `m1-5-local-universe-ui`; this exact SHA was verified at task start.
- Worktree: `/workspace/gim51-celestial-attachment`, local branch `gim51-celestial-attachment`, based directly on the required SHA.
- No commit, push, new PR, merge, or edit to PR #5 was made. GIM-52 and GIM-53 work was not started.

## Projection correction

The production controller projects node centers with the current camera transform but scales each body group only by `node.radius / BODY_BASE_RADIUS`. The orthographic frustum is sized in CSS pixels, so a WebGL sphere projects to `node.radius` CSS pixels at every zoom. The relationship Canvas instead transforms scene coordinates by `k × effectiveDPR`, with `effectiveDPR = min(devicePixelRatio, 2)`. Clipping against raw `node.radius` therefore produced a screen radius of `node.radius × k`, which caused detached ends and body crossings away from `k = 1`.

For WebGL-backed bodies, the renderer now uses `node.radius / k` in pre-zoom Canvas coordinates for path clipping, `destination-out` masks, and label clearance. The Canvas transform projects that radius back to `node.radius` CSS pixels. The Canvas-only fallback retains the raw scene radius because its bodies share the same Canvas zoom transform. Stroke, cue, and badge dimensions are converted from CSS pixels to world units by dividing by `k`. Opacity mask cutoff is aligned with the production body's `0.001` visibility cutoff.

The curve remains the existing quadratic. Its intersections are clipped against both effective body circles and the exact middle quadratic segment is retained. The cue follows the clipped curve's forward tangent. Overlapping or too-close bodies suppress a strand when no visible segment can fit. The semantic direction remains **SOURCE — TYPE → TARGET**. The currently displayed interpolated scene is used for both Canvas and WebGL.

An added Three.js camera characterization test uses the production orthographic camera and a radius-50 sphere; it confirms projected body radii of 9, 18, 34, and 48 CSS pixels remain unchanged at `k = 0.3, 0.6, 1, 3`, including DPR 1, 2, and 3. Neither celestial scales, LOD, identities, quality, camera travel, universe motion, nor the WebGL architecture were changed.

## Projection and navigation measurements

A browser analyzer measured Canvas curve endpoints and masks against projected WebGL body boundaries. Before the correction, 6/24 zoom/DPR samples passed; the maximum endpoint error was **68.0000003 CSS px**, the maximum mask error **68 CSS px**, and maximum sampled body intrusion **22.5598 CSS px**. After the correction, **24/24** samples passed with no browser console errors:

- Maximum endpoint-to-sphere boundary error: **0.00000127 CSS px**.
- Maximum mask-to-sphere boundary error: **0.0000000000000018 CSS px** (floating-point rounding).
- Maximum sampled body intrusion: **0 CSS px**.
- Samples cover Rust, Ownership, Stack & Heap, and Operating Systems at `k = 0.3, 0.6, 1, 3` on desktop; Stack & Heap and Operating Systems at those zooms on mobile.

Ten exact 50% focus-transition samples covered Rust → Ownership → Memory → Stack & Heap → Operating Systems → CPUs and the reverse path, with zooms cycling through all four required values. All used the same scene snapshot for displayed bodies and connections and passed attachment checks. Two interrupted transitions were also sampled at 25% (Ownership → Memory at `k = 0.3`; Memory → Stack & Heap at `k = 3`); both passed. A separate Rust → Ownership transition was captured at exact progress 0%, 25%, 50%, 75%, and 100%; all five attachment measurements passed.

Mouse pan of `(+24, +12)` CSS px followed by wheel zoom from `k = 1` to `1.08` retained attachment (maximum error **0.00000024 CSS px**). Pinch changed `k` from 1 to 1.5 and retained attachment at both mobile sizes (maximum errors **0.00000021 CSS px**).

## Screenshots and visual inspection

Before and after images are full-resolution production captures from Chromium 151 / SwiftShader. Static desktop screenshots cover Rust, Ownership, Stack & Heap, and Operating Systems at the four required zooms (1440×900 CSS px, DPR 1). Exact transition screenshots cover 0%, 25%, 50%, 75%, and 100%. The package also includes mobile captures at every required zoom, pinch metadata, and reduced-motion mode.

Mobile capture details:

- **390×844 CSS px, DPR 3**: graph Canvas 390×456 CSS px; Canvas/WebGL backing store 780×912 px due to the 2× cap; screenshot 1170×2532 px.
- **320×700 CSS px, DPR 2**: graph Canvas 320×378 CSS px; backing store 640×756 px; screenshot 640×1400 px.
- Reduced motion: 1440×900 CSS px, DPR 1, Rust at `k = 0.6`.

I inspected full-resolution before/after Operating Systems and Stack & Heap screenshots at `k = 3`, low-zoom examples, both mobile `k = 3` screenshots, and the exact 50% transition. The revised lines meet the solid body boundaries and no longer show the large zoom-dependent gaps or crossings. Near-overlapping links are suppressed. The visible connections can still draw over foreground rings; this remains unresolved below.

## Ring and atmosphere compositing limitation — unresolved

Attachment targets are the projected solid sphere surfaces, with no automatic extension to rings, atmospheres, or coronae. The relationship Canvas is composited above the production WebGL Canvas. Its circular mask matches the solid sphere but cannot sample the WebGL depth buffer to hide a strand behind the front half of a ring or atmosphere. The Operating Systems and Stack & Heap ringed examples show this limitation.

The smallest viable follow-up is to put the strand-only Canvas below the existing WebGL layer, while keeping cues and badges on an overlay above it. This would split relationship content by layer while preserving the single `WebGLRenderer`. No renderer compositing change was made in this revision; ring occlusion must remain an explicit acceptance limitation.

## Automated validation

Starting baseline: 31 files / 249 tests. Current suite: **32 files / 284 tests passed**.

| Command | Result |
| --- | --- |
| `npm ci` | Passed; 444 packages installed |
| `npm run format:check` | Passed |
| `npm run lint` | Passed |
| `npm run typecheck` | Passed |
| `npm run test` | Passed; 32 files, 284 tests |
| `npm run build` | Passed; Next.js 16.3.8, 13 static pages generated |
| `git diff --check` | Passed |

Coverage includes projected endpoint and mask radii, production camera projection, DPR scaling, Canvas-only fallback, clipped tangents and direction, different curvatures, focus-radius interpolation, overlapping and near-touching bodies, nonfinite geometry inputs, zero relationship opacity, labels, and desktop/mobile CSS coordinate handling.

Reported environment notices: `npm ci` emitted `EBADENGINE` because this environment uses Node `v24.19.0` while `package.json` requires `>=22.12.0 <23`; npm also reported deprecated `eslint@9.39.5`. Tests passed with the existing jsdom Canvas `getContext()` notices and Vitest's advisory about 32 jsdom environments (27.43 seconds total). Lint, format, typecheck, build, and diff check reported no project errors.

## Canvas and frame cost — Chromium / SwiftShader only

Before and after use the same production browser harness, viewport (1440×900 CSS px, DPR 1), Chromium 151, and SwiftShader renderer. Canvas timing covers the outer `renderUniverseScene` pass, including stars, relationship drawing, labels, and masks. It is not a hardware-GPU measurement.

| Cold transition | Canvas p50 / p95 / max before (ms) | Canvas p50 / p95 / max after (ms) | Wall time before → after (ms) |
| --- | ---: | ---: | ---: |
| Rust → CPUs | 0.9 / 1.6 / 1.6 | 0.6 / 13.3 / 13.3 | 2102 → 1867 |
| Rust → Transistors | 0.4 / 6.2 / 6.2 | 0.3 / 17.3 / 17.3 | 1784 → 1897 |
| Ownership → CPUs | 0.7 / 17.4 / 17.4 | 0.5 / 7.4 / 7.4 | 1980 → 1956 |
| Ownership → Transistors | 0.7 / 25.9 / 25.9 | 0.5 / 0.7 / 0.7 | 1765 → 1277 |
| Warm, 30 transitions | 0.7 / 6.1 / 41.0 | 0.8 / 6.3 / 38.1 | — |

For the warm run, frame interval p50/p95/max was 16.7/566.6/1049.9 ms before and 50/600/900 ms after. Counts above 33.3/50/100 ms were 144/142/140 before and 136/135/134 after. Long Tasks were 71 (30,236 ms total; 791 ms max) before and 65 (30,252 ms total; 833 ms max) after. The four cold frame distributions and exact threshold counts are in `revision-before/performance.json` and `revision-after/performance.json`.

Warm resources were identical: 30 entries, 786,930 transferred bytes, 777,930 decoded bytes. Warm cache counters were 12 hits, zero misses, zero body creates, and zero shader preparations in both runs. Cold shader preparations had zero failures; the after run recorded 8 starts/completions and 1 cancellation versus 9 starts/completions and 2 cancellations before. SwiftShader produced large and variable frame stalls, so these results do not support a hardware-GPU performance claim.

## Source files changed

- Added `src/features/knowledge-graph/rendering/relationship-path.ts`
- Added `src/features/knowledge-graph/rendering/relationship-path.test.ts`
- Updated `src/features/knowledge-graph/rendering/universe-renderer.ts`
- Updated `src/features/knowledge-graph/rendering/universe-renderer.test.ts`
- Updated `src/features/knowledge-graph/celestial-3d/production-controller.test.ts`
- Updated `src/features/knowledge-graph/rendering/hit-test.test.ts`

## Artifacts and review status

- `revision-before/` and `revision-after/`: full-resolution PNGs, contact sheets, scene metadata, and projection measurements.
- `revision-after/navigation.json`, `input-gestures.json`, `exact-transition-measurements.json`, and `performance.json`: detailed browser results.
- `gim51-projection-revision.patch`: focused correction patch, applicable after the original GIM-51 patch.
- `gim51-celestial-attachment-revised.patch`: complete task patch against the required starting SHA; `git apply --check` passed on a clean worktree.
- All generated QA artifacts are outside tracked source. The isolated worktree remains uncommitted and unpublished; this task is stopped for independent review.
