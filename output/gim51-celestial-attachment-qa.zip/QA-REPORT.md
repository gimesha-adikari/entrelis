# GIM-51 — Celestial-Surface Connection Anchoring

## Starting revision and workspace

- Required remote branch: `m1-5-local-universe-ui`
- Verified branch head at task start: `40969c43004d792c0f18658ccd97fbb632bdb967`
- Isolated worktree: `/workspace/gim51-celestial-attachment`, local branch `gim51-celestial-attachment`, based on that exact SHA.
- The remote branch matched the required SHA when fetched. No commit or push was made; PR #5 was not modified.

## Geometry and drawing

`src/features/knowledge-graph/rendering/relationship-path.ts` is a pure geometry module. It starts with the existing semantic source-to-target quadratic and finds its circle intersections by recursively isolating roots of the quartic distance polynomial (derivative critical points plus bounded bisection). It keeps the middle Bézier segment by de Casteljau subdivision, then verifies that segment stays outside each endpoint circle. This retains the original curve shape while replacing center endpoints with exact physical-surface endpoints. If endpoint circles overlap, leave at most one CSS pixel of visible gap, or the clipped segment crosses either endpoint body, it suppresses the strand. A short strand can remain without a directional cue.

The cue is placed eight CSS pixels back from the target along the clipped curve and follows its derivative at that point. SOURCE → TYPE → TARGET direction is unchanged. Geometry is recalculated from the current `UniverseScene`, including interpolated node radii.

Canvas line widths, cue dimensions, badge text, padding and borders are converted from CSS pixels to world units by dividing by `k`. The existing Canvas transform then applies `k × effectiveDPR` (DPR capped at 2), leaving those marks stable in CSS pixels. Node sizes and celestial LOD were not changed.

The existing `GraphCanvas` already passes `currentSceneRef.current` to both relationship drawing and the production celestial controller each frame. Runtime checks confirmed those are the same scene object through all sampled focus transitions, including interrupted transitions. `GraphCanvas` and `production-controller.ts` did not require changes.

## Visual and interaction QA

Production Next.js output was served locally and inspected with Playwright/Chromium 151 on SwiftShader. Before images were captured from a separate worktree at the verified starting SHA. Before and after desktop states cover Rust, Ownership, Stack & Heap, and Operating Systems at `k = 0.3, 0.6, 1.0, 3.0` (1440×900 CSS pixels, DPR 1). The exact sampled transition captures are Rust → Ownership at 0%, 27.19%, 50.64%, 76.99%, and 100%.

Desktop navigation exercised Rust → Ownership → Memory → Stack & Heap → Operating Systems → CPUs and the full reverse path. Ten midpoint samples and both interrupted-transition samples used the same displayed scene snapshot as the celestial bodies. At those samples, all 92 directed path copies matched their masked physical circles; worst endpoint boundary error was under `0.000001` world units, with no sampled endpoint-body intrusion. The separate 30-sample warm cycle check also had zero measured boundary error beyond numerical root tolerance.

Desktop mouse pan (`+24,+12` CSS px) and wheel zoom (`1.0 → 1.08`) retained attached endpoints. Mobile pinch changed `k` from 1.0 to 1.5 at both requested viewports:

- 390×844 CSS px, actual DPR 3, graph Canvas 390×456 CSS px, backing 780×912 px (effective DPR cap 2), screenshot 1170×2532 px.
- 320×700 CSS px, actual DPR 2, graph Canvas 320×378 CSS px, backing 640×756 px, screenshot 640×1400 px.

Reduced-motion mode was captured at 1440×900, DPR 1, Rust at `k = 0.6`. Browser console and page errors were empty for the final captures.

The before/after contact sheets were inspected. At all four zooms the updated strands meet the sphere surfaces without the old center-anchored rod appearance; k=3 stroke and cue dimensions remain restrained. The Operating Systems ringed giant retains the known layer-order limitation described below.

## Canvas/WebGL layering limitation

Solid sphere boundaries are the attachment surfaces. Atmospheres/corona and rings remain separately rendered WebGL features; this change does not extend every connection to a halo or ring. The relationship Canvas is composited above the production WebGL canvas. Its `destination-out` mask clears the projected solid-body circles, but cannot use the WebGL depth buffer to hide a strand behind the front half of a ring or atmosphere. The Operating Systems rings can therefore have a connection drawn over them.

Smallest viable follow-up: render the strand-only Canvas beneath the existing WebGL canvas so solid bodies and front rings naturally occlude it, while keeping directional cues and badges on an overlay above WebGL. This requires splitting the current relationship layer by content, but preserves the single `WebGLRenderer`; no GPU readback or silhouette reconstruction is needed. It was not implemented in GIM-51.

## Automated validation

Starting baseline: 31 test files / 249 tests. Final suite: **32 files / 261 tests passed**.

| Command | Result |
| --- | --- |
| `npm ci` | Passed; 444 packages installed |
| `npm run format:check` | Passed |
| `npm run lint` | Passed |
| `npm run typecheck` | Passed |
| `npm run test` | Passed; 32 files, 261 tests |
| `npm run build` | Passed; Next.js 16.3.8, 13 static pages generated |
| `git diff --check` | Passed |

Coverage added for circle-boundary endpoints, curve clearance across positive/negative curvatures, curve tangents and cue direction, large-focus/small-context radii, short/overlapping/near-touching bodies, nonfinite dimensions and zoom, interpolated focus radii, zoom/DPR-invariant screen sizing, opacity zero, and desktop/mobile hit-test coordinates. Existing relationship lifecycle tests remain in place.

Warnings: the cloud runtime is Node `v24.19.0`, while `package.json` specifies `>=22.12.0 <23`; npm emitted `EBADENGINE`, but install, tests and production build succeeded. npm also reported deprecated `eslint@9.39.5`. Vitest's jsdom runs emitted the existing “HTMLCanvasElement.getContext() not implemented” notices and its advisory that jsdom was created 32 times (28.08 seconds); neither failed tests. Formatting, lint, typecheck, and build emitted no project errors.

The first attempt to build the temporary baseline worktree with a `node_modules` symlink hit a Turbopack filesystem-root restriction. The baseline was then installed locally with `npm ci` at the exact required SHA and its production build succeeded.

## Performance (cloud Chromium / SwiftShader only)

Renderer: `ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)`. Desktop viewport 1440×900, DPR 1. These are instrumented software-rendering measurements from this cloud run, not hardware-GPU claims.

Canvas timing spans the outer `renderUniverseScene` save/restore pass, so it includes background stars, relationship paths, masks, and labels rather than only the path loop. Frame intervals are sampled between instrumented page `requestAnimationFrame` callbacks, not physical display/GPU presentation timestamps.

Four fresh-context cold transitions all targeted concepts absent from the initial scene:

| Transition | Wall time | Frame interval p50 / p95 / max | Frames >33.3 / >50 / >100 ms | Canvas draw p50 / p95 / max | Long Tasks |
| --- | ---: | ---: | ---: | ---: | ---: |
| Rust → CPUs | 1344 ms | 16.7 / 1016.7 / 1016.7 ms | 3 / 3 / 3 | 1.0 / 2.3 / 2.3 ms | 3 |
| Rust → Transistors | 1324 ms | 0 / 750 / 750 ms | 3 / 3 / 3 | 0.4 / 3.4 / 3.4 ms | 3 |
| Ownership → CPUs | 1014 ms | 16.7 / 450 / 450 ms | 3 / 3 / 3 | 0.9 / 4.0 / 4.0 ms | 3 |
| Ownership → Transistors | 2109 ms | 16.7 / 1350 / 1350 ms | 4 / 4 / 4 | 0.6 / 0.7 / 0.7 ms | 3 |

Across three warmed forward/reverse navigation cycles (30 transitions), relationship Canvas drawing was **0.6 / 5.5 / 52.6 ms p50/p95/max**. Frame intervals were **16.7 / 516.6 / 766.6 ms**, with **138 / 138 / 137** frames above 33.3 / 50 / 100 ms. The run recorded 69 Long Tasks, 28,034 ms total and 761 ms max; RAF callback time was 1.4 / 495.5 / 755.9 ms p50/p95/max. These long stalls are visible in the cloud software-rendered run and should not be treated as a hardware baseline.

Cold shader preparation started/completed 1–2 preparations per transition; failures were zero and one cancellation was recorded on three transitions. Warm cycles recorded 12 warm-cache hits, zero misses, zero body creations, and no shader preparations. Timed Resource Timing entries: 30 entries, 786,930 transfer bytes and 777,930 decoded bytes in the warm run; each cold run recorded one entry (26,231 transfer bytes, 25,931 decoded bytes).

## Files changed

- Added `src/features/knowledge-graph/rendering/relationship-path.ts`
- Added `src/features/knowledge-graph/rendering/relationship-path.test.ts`
- Updated `src/features/knowledge-graph/rendering/universe-renderer.ts`
- Updated `src/features/knowledge-graph/rendering/universe-renderer.test.ts`
- Updated `src/features/knowledge-graph/rendering/hit-test.test.ts`

## Artifacts

- `before/` and `after/`: full-resolution captures and metadata.
- `comparison-*.jpg`, `transition-rust-ownership.jpg`, and per-phase contact sheets: inspected visual comparisons.
- `navigation.json`, `input-gestures.json`, and `performance.json`: recorded browser results.
- `*.log`: validation output.
- `gim51-celestial-attachment.patch`: task-local patch, including the two new source/test files.

The external patch passed `git apply --check` against a clean worktree at the required starting SHA.

All generated QA artifacts are outside tracked source. This work is stopped for review; it is not committed or pushed.
