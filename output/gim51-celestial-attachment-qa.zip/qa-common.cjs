const { chromium } = require("/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

const BASE_URL = "http://127.0.0.1:3000";
const GRAPH_SNAPSHOT_EXPRESSION = `(() => {
  const canvas = [...document.querySelectorAll('canvas')].find((item) => !item.hasAttribute('data-production-celestial-layer'));
  if (!canvas) return null;
  const graphFiberKey = Object.keys(canvas).find((key) => key.startsWith('__reactFiber$'));
  let fiber = graphFiberKey ? canvas[graphFiberKey] : null;
  let graph = null;
  while (fiber) {
    const hooks = [];
    for (let hook = fiber.memoizedState; hook; hook = hook.next) hooks.push(hook);
    const states = hooks.map((hook) => hook.memoizedState);
    const sceneRef = states.find((state) => state?.current?.allNodes && state.current.relationships);
    const transformRef = states.find((state) => state?.current && typeof state.current.k === 'number' && typeof state.current.x === 'number');
    const travelRef = states.find((state) => state?.current && typeof state.current.active === 'boolean' && typeof state.current.progress === 'number');
    if (sceneRef && transformRef) { graph = { fiber, hooks, sceneRef, transformRef, travelRef }; break; }
    fiber = fiber.return;
  }
  if (!graph) return null;

  const productionCanvas = document.querySelector('[data-production-celestial-layer]');
  let controllerStats = null;
  let latestScene = null;
  if (productionCanvas) {
    const productionFiberKey = Object.keys(productionCanvas).find((key) => key.startsWith('__reactFiber$'));
    let productionFiber = productionFiberKey ? productionCanvas[productionFiberKey] : null;
    while (productionFiber && (!controllerStats || !latestScene)) {
      for (let hook = productionFiber.memoizedState; hook; hook = hook.next) {
        const current = hook.memoizedState?.current;
        if (current && typeof current.getLifecycleStats === 'function') controllerStats = current.getLifecycleStats();
        if (Array.isArray(current) && current[0]?.allNodes && current[0].relationships) latestScene = current[0];
      }
      productionFiber = productionFiber.return;
    }
  }
  const scene = graph.sceneRef.current;
  let renderer = null;
  if (productionCanvas) {
    const gl = productionCanvas.getContext('webgl2');
    const debug = gl?.getExtension('WEBGL_debug_renderer_info');
    renderer = debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : gl?.getParameter(gl.RENDERER) ?? null;
  }
  return {
    scene,
    transform: graph.transformRef.current,
    travel: graph.travelRef?.current ?? null,
    controllerStats,
    sameDisplayedScene: latestScene === scene,
    canvas: { width: canvas.width, height: canvas.height, rect: canvas.getBoundingClientRect().toJSON() },
    productionCanvas: productionCanvas ? { width: productionCanvas.width, height: productionCanvas.height, renderer } : null,
    viewport: { width: window.innerWidth, height: window.innerHeight, devicePixelRatio: window.devicePixelRatio },
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    userAgent: navigator.userAgent,
    url: window.location.pathname,
  };
})()`;

function installDiagnostics(options = {}) {
  const metrics = {
    canvasDrawMs: [],
    rafCallbackMs: [],
    frameIntervalsMs: [],
    longTasks: [],
    pathCommands: [],
    bodyCircles: [],
    drawSequence: 0,
    lastFrameTimestamp: null,
  };
  Object.defineProperty(window, "__gim51QA", { value: metrics, configurable: true });

  const isGraphCanvasContext = (context) =>
    context?.canvas?.getAttribute("aria-hidden") === "true" &&
    !context.canvas.hasAttribute("data-production-celestial-layer");
  const states = new WeakMap();
  const prototype = window.CanvasRenderingContext2D.prototype;
  const originalSave = prototype.save;
  const originalRestore = prototype.restore;
  const originalMoveTo = prototype.moveTo;
  const originalQuadraticCurveTo = prototype.quadraticCurveTo;
  const originalArc = prototype.arc;

  prototype.save = function (...args) {
    if (isGraphCanvasContext(this)) {
      let state = states.get(this);
      if (!state) state = { depth: 0, startedAt: 0, drawId: 0, lastMove: null };
      if (state.depth === 0) {
        state.startedAt = performance.now();
        state.drawId = ++metrics.drawSequence;
        state.lastMove = null;
      }
      state.depth += 1;
      states.set(this, state);
    }
    return originalSave.apply(this, args);
  };
  prototype.restore = function (...args) {
    const state = isGraphCanvasContext(this) ? states.get(this) : null;
    const result = originalRestore.apply(this, args);
    if (state && state.depth > 0) {
      state.depth -= 1;
      if (state.depth === 0) {
        metrics.canvasDrawMs.push(performance.now() - state.startedAt);
        state.lastMove = null;
      }
    }
    return result;
  };
  prototype.moveTo = function (x, y) {
    const state = isGraphCanvasContext(this) ? states.get(this) : null;
    if (state) state.lastMove = { x, y };
    return originalMoveTo.call(this, x, y);
  };
  prototype.quadraticCurveTo = function (cx, cy, x, y) {
    const state = isGraphCanvasContext(this) ? states.get(this) : null;
    if (state && state.depth > 0 && state.lastMove) {
      metrics.pathCommands.push({
        drawId: state.drawId,
        start: state.lastMove,
        control: { x: cx, y: cy },
        end: { x, y },
        time: performance.now(),
      });
    }
    return originalQuadraticCurveTo.call(this, cx, cy, x, y);
  };
  prototype.arc = function (x, y, radius, ...args) {
    const state = isGraphCanvasContext(this) ? states.get(this) : null;
    if (state && state.depth > 0 && this.globalCompositeOperation === "destination-out") {
      metrics.bodyCircles.push({ drawId: state.drawId, center: { x, y }, radius });
    }
    return originalArc.call(this, x, y, radius, ...args);
  };

  const originalRequestAnimationFrame = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = (callback) =>
    originalRequestAnimationFrame((timestamp) => {
      if (metrics.lastFrameTimestamp !== null) {
        metrics.frameIntervalsMs.push(timestamp - metrics.lastFrameTimestamp);
      }
      metrics.lastFrameTimestamp = timestamp;
      const startedAt = performance.now();
      try {
        callback(timestamp);
      } finally {
        metrics.rafCallbackMs.push(performance.now() - startedAt);
      }
    });

  if (options.slowTransitionClock) {
    const nativeNow = performance.now.bind(performance);
    const origin = nativeNow();
    const scale = options.clockScale ?? 0.1;
    const diagnosticRequestAnimationFrame = window.requestAnimationFrame.bind(window);
    const clock = { realOrigin: origin, fakeOrigin: origin, scale };
    window.__gim51QAClock = clock;
    window.__gim51SetClockScale = (nextScale) => {
      const fakeNow = performance.now();
      clock.realOrigin = nativeNow();
      clock.fakeOrigin = fakeNow;
      clock.scale = nextScale;
    };
    Object.defineProperty(performance, "now", {
      configurable: true,
      value: () => clock.fakeOrigin + (nativeNow() - clock.realOrigin) * clock.scale,
    });
    window.requestAnimationFrame = (callback) =>
      diagnosticRequestAnimationFrame((timestamp) =>
        callback(clock.fakeOrigin + (timestamp - clock.realOrigin) * clock.scale)
      );
  }

  if (typeof PerformanceObserver !== "undefined") {
    try {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          metrics.longTasks.push({ startTime: entry.startTime, duration: entry.duration });
        }
      });
      observer.observe({ type: "longtask", buffered: true });
    } catch {}
  }
}

async function launchBrowser() {
  return chromium.launch({
    headless: true,
    executablePath: "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--enable-webgl",
      "--ignore-gpu-blocklist",
      "--use-gl=angle",
      "--use-angle=swiftshader",
      "--enable-unsafe-swiftshader",
    ],
  });
}

async function createPage(browser, options = {}) {
  const context = await browser.newContext({
    viewport: options.viewport ?? { width: 1440, height: 900 },
    deviceScaleFactor: options.deviceScaleFactor ?? 1,
    isMobile: options.isMobile ?? false,
    hasTouch: options.hasTouch ?? false,
    reducedMotion: options.reducedMotion ?? "no-preference",
  });
  const page = await context.newPage();
  page.addInitScript(installDiagnostics, {
    slowTransitionClock: options.slowTransitionClock ?? false,
    clockScale: options.clockScale,
  });
  return { context, page };
}

async function waitForGraph(page, slug) {
  await page.waitForFunction(
    ({ expression, expectedSlug }) => {
      const snapshot = eval(expression);
      return (
        snapshot?.scene?.focus?.slug === expectedSlug &&
        snapshot?.controllerStats?.rendererAvailable === true
      );
    },
    { expression: GRAPH_SNAPSHOT_EXPRESSION, expectedSlug: slug },
    { timeout: 30000 }
  );
}

async function openFocus(page, slug) {
  const route = slug === "rust" ? "/" : `/concept/${slug}`;
  const response = await page.goto(`${BASE_URL}${route}`, { waitUntil: "networkidle" });
  if (!response || response.status() !== 200) throw new Error(`HTTP ${response?.status()} for ${route}`);
  await waitForGraph(page, slug);
  await page.waitForTimeout(180);
}

async function getSnapshot(page) {
  return page.evaluate((expression) => eval(expression), GRAPH_SNAPSHOT_EXPRESSION);
}

async function setZoom(page, zoom) {
  await page.evaluate(
    ({ expression, zoom }) => {
      const snapshot = eval(expression);
      if (!snapshot) throw new Error("GraphCanvas hooks unavailable");
      snapshot.transform.k = zoom;
      const canvas = [...document.querySelectorAll("canvas")].find(
        (item) => !item.hasAttribute("data-production-celestial-layer")
      );
      const propsKey = Object.keys(canvas).find((key) => key.startsWith("__reactProps$"));
      const props = canvas[propsKey];
      const rect = canvas.getBoundingClientRect();
      const event = { clientX: rect.left + 24, clientY: rect.top + 24 };
      props.onMouseDown(event);
      props.onMouseMove(event);
      props.onMouseUp({ clientX: event.clientX + 8, clientY: event.clientY });
    },
    { expression: GRAPH_SNAPSHOT_EXPRESSION, zoom }
  );
  await page.waitForTimeout(90);
}

async function selectConcept(page, slug, useVisibleControl = true) {
  await page.evaluate(
    ({ slug, useVisibleControl }) => {
      if (useVisibleControl) {
        const control = document.querySelector(`[data-concept-slug="${slug}"]`);
        if (control) {
          const propsKey = Object.keys(control).find((key) => key.startsWith("__reactProps$"));
          control[propsKey].onClick();
          return;
        }
      }
      const url = `/concept/${slug}`;
      window.history.pushState({ slug }, "", url);
      window.dispatchEvent(new PopStateEvent("popstate"));
    },
    { slug, useVisibleControl }
  );
  await page.waitForFunction(
    ({ expression, slug }) => {
      const snapshot = eval(expression);
      return location.pathname.endsWith(`/concept/${slug}`) && snapshot?.travel?.active === true;
    },
    { expression: GRAPH_SNAPSHOT_EXPRESSION, slug },
    { timeout: 10000 }
  );
  await page.waitForFunction(
    ({ expression, slug }) => {
      const snapshot = eval(expression);
      return (
        location.pathname.endsWith(`/concept/${slug}`) &&
        snapshot?.scene?.focus?.slug === slug &&
        snapshot?.travel?.active === false &&
        snapshot?.travel?.progress === 1
      );
    },
    { expression: GRAPH_SNAPSHOT_EXPRESSION, slug },
    { timeout: 10000 }
  );
}

async function waitForProgress(page, progress) {
  await page.waitForFunction(
    ({ expression, progress }) => {
      const snapshot = eval(expression);
      return snapshot?.travel?.active === true && snapshot.travel.progress >= progress;
    },
    { expression: GRAPH_SNAPSHOT_EXPRESSION, progress },
    { timeout: 30000 }
  );
  return getSnapshot(page);
}

async function clearDiagnostics(page) {
  await page.evaluate(() => {
    const metrics = window.__gim51QA;
    metrics.canvasDrawMs.length = 0;
    metrics.rafCallbackMs.length = 0;
    metrics.frameIntervalsMs.length = 0;
    metrics.longTasks.length = 0;
    metrics.pathCommands.length = 0;
    metrics.bodyCircles.length = 0;
    metrics.lastFrameTimestamp = null;
    performance.clearResourceTimings();
  });
}

async function getDiagnostics(page) {
  return page.evaluate(() => {
    const metrics = window.__gim51QA;
    const resources = performance.getEntriesByType("resource");
    return {
      canvasDrawMs: [...metrics.canvasDrawMs],
      rafCallbackMs: [...metrics.rafCallbackMs],
      frameIntervalsMs: [...metrics.frameIntervalsMs],
      longTasks: [...metrics.longTasks],
      pathCommands: [...metrics.pathCommands],
      bodyCircles: [...metrics.bodyCircles],
      resources: {
        count: resources.length,
        transferSizeBytes: resources.reduce((sum, entry) => sum + (entry.transferSize || 0), 0),
        decodedBodySizeBytes: resources.reduce((sum, entry) => sum + (entry.decodedBodySize || 0), 0),
      },
    };
  });
}

function summarizeNumbers(values) {
  if (values.length === 0) return { count: 0, p50: null, p95: null, max: null };
  const sorted = [...values].sort((left, right) => left - right);
  const percentile = (fraction) => sorted[Math.max(0, Math.ceil(sorted.length * fraction) - 1)];
  return {
    count: sorted.length,
    p50: percentile(0.5),
    p95: percentile(0.95),
    max: sorted[sorted.length - 1],
  };
}

function summarizeFrames(values) {
  return {
    ...summarizeNumbers(values),
    above33_3ms: values.filter((value) => value > 33.3).length,
    above50ms: values.filter((value) => value > 50).length,
    above100ms: values.filter((value) => value > 100).length,
  };
}

function analyzeAttachments(snapshot, pathCommands, bodyCircles = []) {
  if (!snapshot?.scene) return { drawId: null, pathCount: 0, matchedPathCount: 0, allAttached: false };
  const zoom = snapshot.transform?.k;
  if (!Number.isFinite(zoom) || zoom <= 0) {
    return { drawId: null, pathCount: 0, matchedPathCount: 0, allAttached: false };
  }
  const drawId = Math.max(-1, ...pathCommands.map((path) => path.drawId));
  const paths = pathCommands.filter((path) => path.drawId === drawId);
  const nodes = new Map(snapshot.scene.allNodes.map((node) => [node.id, node]));
  const circles = bodyCircles.filter((circle) => circle.drawId === drawId);
  const relationships = snapshot.scene.relationships.filter((relationship) => relationship.opacity > 0.001);
  let matchedPathCount = 0;
  let worstBoundaryErrorCssPx = 0;
  let maximumBodyIntrusionCssPx = 0;
  const matchedRelationshipIds = new Set();
  let allAttached = true;

  for (const path of paths) {
    const candidates = relationships.flatMap((relationship) => {
      const source = nodes.get(relationship.sourceId);
      const target = nodes.get(relationship.targetId);
      if (!source || !target) return [];
      const sourceError = Math.abs(
        Math.hypot(path.start.x - source.x, path.start.y - source.y) * zoom - source.radius
      );
      const targetError = Math.abs(
        Math.hypot(path.end.x - target.x, path.end.y - target.y) * zoom - target.radius
      );
      return [{ relationship, source, target, sourceError, targetError }];
    });
    const best = candidates.sort(
      (left, right) =>
        left.sourceError + left.targetError - (right.sourceError + right.targetError)
    )[0];
    if (!best) {
      allAttached = false;
      continue;
    }
    if (best.sourceError > 0.5 || best.targetError > 0.5) allAttached = false;
    matchedPathCount += 1;
    matchedRelationshipIds.add(best.relationship.id);
    worstBoundaryErrorCssPx = Math.max(worstBoundaryErrorCssPx, best.sourceError, best.targetError);
    for (let index = 1; index < 40; index += 1) {
      const t = index / 40;
      const inverse = 1 - t;
      const x = inverse * inverse * path.start.x + 2 * inverse * t * path.control.x + t * t * path.end.x;
      const y = inverse * inverse * path.start.y + 2 * inverse * t * path.control.y + t * t * path.end.y;
      const sourceIntrusion = best.source.radius - Math.hypot(x - best.source.x, y - best.source.y) * zoom;
      const targetIntrusion = best.target.radius - Math.hypot(x - best.target.x, y - best.target.y) * zoom;
      maximumBodyIntrusionCssPx = Math.max(maximumBodyIntrusionCssPx, sourceIntrusion, targetIntrusion);
    }
  }
  let worstMaskBoundaryErrorCssPx = 0;
  let matchedMaskCount = 0;
  for (const circle of circles) {
    const node = snapshot.scene.allNodes.find((candidate) => candidate.x === circle.center.x && candidate.y === circle.center.y);
    if (!node) {
      allAttached = false;
      continue;
    }
    const error = Math.abs(circle.radius * zoom - node.radius);
    worstMaskBoundaryErrorCssPx = Math.max(worstMaskBoundaryErrorCssPx, error);
    matchedMaskCount += 1;
  }
  const visibleMaskNodeCount = snapshot.scene.allNodes.filter((node) => node.opacity > 0.001).length;
  if (circles.length > 0 && matchedMaskCount !== visibleMaskNodeCount) allAttached = false;
  return {
    drawId,
    zoom,
    pathCount: paths.length,
    matchedPathCount,
    matchedRelationshipCount: matchedRelationshipIds.size,
    activeRelationshipCount: relationships.length,
    suppressedRelationshipCount: Math.max(0, relationships.length - matchedRelationshipIds.size),
    worstBoundaryErrorCssPx,
    maximumBodyIntrusionCssPx: Math.max(0, maximumBodyIntrusionCssPx),
    maskCount: circles.length,
    worstMaskBoundaryErrorCssPx,
    allAttached,
  };
}

function aggregateDiagnostics(runs) {
  const allCanvasDraws = runs.flatMap((run) => run.diagnostics.canvasDrawMs);
  const allRafCallbacks = runs.flatMap((run) => run.diagnostics.rafCallbackMs);
  const allFrames = runs.flatMap((run) => run.diagnostics.frameIntervalsMs);
  const allLongTasks = runs.flatMap((run) => run.diagnostics.longTasks);
  return {
    relationshipCanvasDrawMs: summarizeNumbers(allCanvasDraws),
    rafCallbackMs: summarizeNumbers(allRafCallbacks),
    frameIntervalMs: summarizeFrames(allFrames),
    longTasks: {
      count: allLongTasks.length,
      totalDurationMs: allLongTasks.reduce((sum, task) => sum + task.duration, 0),
      maxDurationMs: allLongTasks.reduce((maximum, task) => Math.max(maximum, task.duration), 0),
    },
  };
}

module.exports = {
  BASE_URL,
  GRAPH_SNAPSHOT_EXPRESSION,
  aggregateDiagnostics,
  analyzeAttachments,
  clearDiagnostics,
  createPage,
  getDiagnostics,
  getSnapshot,
  launchBrowser,
  openFocus,
  selectConcept,
  setZoom,
  summarizeFrames,
  summarizeNumbers,
  waitForGraph,
  waitForProgress,
};
