from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
ROOT = Path('/workspace/gim51-qa')
BEFORE = ROOT / 'revision-before'
AFTER = ROOT / 'revision-after'
ZOOMS = ['0.3', '0.6', '1', '3']
SLUGS = ['rust', 'ownership', 'stack-and-heap', 'operating-systems']
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 12)
thumb_w, thumb_h, label_h = 480, 300, 26
for slug in SLUGS:
    sheet = Image.new('RGB', (2 * thumb_w + 3 * 14, 4 * (thumb_h + label_h) + 14), '#101522')
    draw = ImageDraw.Draw(sheet)
    for row, zoom in enumerate(ZOOMS):
        y = 14 + row * (thumb_h + label_h)
        draw.text((14, y), f'{slug}   k={zoom}', font=font, fill='#ffffff')
        for col, (label, folder) in enumerate([('BEFORE', BEFORE), ('AFTER', AFTER)]):
            image = Image.open(folder / f'{slug}-k{zoom}-dpr1.png').convert('RGB')
            image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
            x = 14 + col * (thumb_w + 14)
            draw.text((x, y + 8), label, font=small, fill='#8bd5ff')
            sheet.paste(image, (x, y + label_h))
    sheet.save(AFTER / f'{slug}-before-after-contact.jpg', quality=92)

thumb_w, thumb_h, label_h = 260, 163, 25
sheet = Image.new('RGB', (4 * thumb_w, 4 * (thumb_h + label_h)), '#101522')
draw = ImageDraw.Draw(sheet)
for row, slug in enumerate(SLUGS):
    for col, zoom in enumerate(ZOOMS):
        x, y = col * thumb_w, row * (thumb_h + label_h)
        draw.text((x + 8, y + 4), f'{slug}  k={zoom}', font=small, fill='#ffffff')
        image = Image.open(AFTER / f'{slug}-k{zoom}-dpr1.png').convert('RGB')
        image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
        sheet.paste(image, (x, y + label_h))
sheet.save(AFTER / 'contact-sheet.png')

thumb_w, thumb_h = 350, 219
sheet = Image.new('RGB', (5 * thumb_w, thumb_h + 34), '#101522')
draw = ImageDraw.Draw(sheet)
for index, pct in enumerate([0, 25, 50, 75, 100]):
    draw.text((index * thumb_w + 8, 4), f'{pct}%', font=font, fill='#ffffff')
    image = Image.open(AFTER / f'transition-rust-to-ownership-p{pct}.png').convert('RGB')
    image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
    sheet.paste(image, (index * thumb_w, 34))
sheet.save(AFTER / 'transition-contact-sheet.jpg', quality=92)
