const fs = require('node:fs');
const path = require('node:path');
const qa = require('./qa-common.cjs');
const phase = process.argv[2] ?? 'revision-after';
const output = { phase, zooms: [0.3, 0.6, 1, 3], results: [], consoleErrors: [] };

(async () => {
  const browser = await qa.launchBrowser();
  try {
    const environments = [
      { kind: 'desktop', viewport: { width: 1440, height: 900 }, dpr: 1, slug: 'rust' },
      { kind: 'desktop', viewport: { width: 1440, height: 900 }, dpr: 1, slug: 'ownership' },
      { kind: 'desktop', viewport: { width: 1440, height: 900 }, dpr: 1, slug: 'stack-and-heap' },
      { kind: 'desktop', viewport: { width: 1440, height: 900 }, dpr: 1, slug: 'operating-systems' },
      { kind: 'mobile', viewport: { width: 390, height: 844 }, dpr: 3, slug: 'stack-and-heap', isMobile: true, hasTouch: true },
      { kind: 'mobile', viewport: { width: 320, height: 700 }, dpr: 2, slug: 'operating-systems', isMobile: true, hasTouch: true },
    ];
    for (const environment of environments) {
      const { context, page } = await qa.createPage(browser, {
        viewport: environment.viewport,
        deviceScaleFactor: environment.dpr,
        isMobile: environment.isMobile,
        hasTouch: environment.hasTouch,
      });
      page.on('console', (message) => { if (message.type() === 'error') output.consoleErrors.push(message.text()); });
      page.on('pageerror', (error) => output.consoleErrors.push(error.message));
      try {
        await qa.openFocus(page, environment.slug);
        for (const zoom of output.zooms) {
          await qa.setZoom(page, zoom);
          await page.waitForTimeout(100);
          const snapshot = await qa.getSnapshot(page);
          const diagnostics = await qa.getDiagnostics(page);
          output.results.push({
            kind: environment.kind,
            slug: environment.slug,
            zoom,
            viewport: snapshot.viewport,
            canvas: snapshot.canvas,
            productionCanvas: snapshot.productionCanvas,
            sameDisplayedScene: snapshot.sameDisplayedScene,
            relationships: snapshot.scene.relationships.length,
            expectedProjectedRadiiCssPx: snapshot.scene.allNodes.map(({ slug, radius, opacity }) => ({ slug, radius, opacity })),
            attachment: qa.analyzeAttachments(snapshot, diagnostics.pathCommands, diagnostics.bodyCircles),
          });
        }
      } finally {
        await context.close();
      }
    }
  } finally {
    await browser.close();
  }
  fs.writeFileSync(path.join('/workspace/gim51-qa', phase, 'projection-measurements.json'), JSON.stringify(output, null, 2));
  console.log(JSON.stringify({ phase, samples: output.results.length, passed: output.results.filter((item) => item.attachment.allAttached).length, failed: output.results.filter((item) => !item.attachment.allAttached).length, consoleErrors: output.consoleErrors, worstEndpointErrorCssPx: Math.max(0, ...output.results.map((item) => item.attachment.worstBoundaryErrorCssPx ?? 0)), worstMaskErrorCssPx: Math.max(0, ...output.results.map((item) => item.attachment.worstMaskBoundaryErrorCssPx ?? 0)), maximumBodyIntrusionCssPx: Math.max(0, ...output.results.map((item) => item.attachment.maximumBodyIntrusionCssPx ?? 0)) }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
