const fs = require('node:fs');
const path = require('node:path');
const qa = require('./qa-common.cjs');
const outputDir = '/workspace/gim51-qa/revision-after';
const result = { phase: 'revision-after', from: 'rust', to: 'ownership', durationMs: 420, samples: [], consoleErrors: [] };

(async () => {
  const browser = await qa.launchBrowser();
  try {
    const { context, page } = await qa.createPage(browser, {
      viewport: { width: 1440, height: 900 },
      deviceScaleFactor: 1,
      slowTransitionClock: true,
      clockScale: 0,
    });
    page.on('console', (message) => { if (message.type() === 'error') result.consoleErrors.push(message.text()); });
    page.on('pageerror', (error) => result.consoleErrors.push(error.message));
    await qa.openFocus(page, 'rust');
    await page.evaluate(() => {
      const control = document.querySelector('[data-concept-slug="ownership"]');
      const propsKey = Object.keys(control).find((key) => key.startsWith('__reactProps$'));
      control[propsKey].onClick();
      window.__gim51GIM51TransitionStart = performance.now();
    });
    await page.waitForFunction((expression) => {
      const snapshot = eval(expression);
      return snapshot?.travel?.active === true && snapshot.travel.toSlug === 'ownership';
    }, qa.GRAPH_SNAPSHOT_EXPRESSION, { timeout: 10000 });

    for (const progress of [0, 0.25, 0.5, 0.75, 1]) {
      await page.evaluate(({ progress, duration }) => {
        window.__gim51QAClock.fakeOrigin = window.__gim51GIM51TransitionStart + progress * duration;
      }, { progress, duration: result.durationMs });
      await page.waitForFunction(({ expression, progress }) => {
        const snapshot = eval(expression);
        return Math.abs((snapshot?.travel?.progress ?? -1) - progress) < 1e-9;
      }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, progress }, { timeout: 10000 });
      const snapshot = await qa.getSnapshot(page);
      const diagnostics = await qa.getDiagnostics(page);
      const attachment = qa.analyzeAttachments(snapshot, diagnostics.pathCommands, diagnostics.bodyCircles);
      const file = `transition-rust-to-ownership-p${Math.round(progress * 100)}.png`;
      await page.screenshot({ path: path.join(outputDir, file) });
      result.samples.push({
        name: file,
        progress: snapshot.travel.progress,
        active: snapshot.travel.active,
        sameDisplayedScene: snapshot.sameDisplayedScene,
        focus: snapshot.scene.focus.slug,
        focusRole: snapshot.scene.allNodes.find((node) => node.role === 'focus')?.slug,
        attachment,
        viewport: snapshot.viewport,
        nodes: snapshot.scene.allNodes.map(({ slug, role, x, y, radius, opacity }) => ({ slug, role, x, y, radius, opacity })),
      });
    }
    await context.close();
  } finally {
    await browser.close();
  }
  fs.writeFileSync(path.join(outputDir, 'exact-transition-measurements.json'), JSON.stringify(result, null, 2));
  const metadataPath = path.join(outputDir, 'metadata.json');
  const metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
  metadata.transitions = result.samples.map((sample) => ({ ...sample, from: result.from, to: result.to, requestedProgress: sample.progress, actualProgress: sample.progress }));
  metadata.transitionClock = { mode: 'frozen RAF clock stepped to exact transition progress', durationMs: result.durationMs };
  fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));
  console.log(JSON.stringify({ samples: result.samples.map(({ name, progress, sameDisplayedScene, attachment }) => ({ name, progress, sameDisplayedScene, attachment })), consoleErrors: result.consoleErrors }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
