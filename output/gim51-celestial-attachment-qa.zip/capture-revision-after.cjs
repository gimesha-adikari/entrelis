const fs = require('node:fs');
const path = require('node:path');
const qa = require('./qa-common.cjs');
const outputDir = '/workspace/gim51-qa/revision-after';
fs.mkdirSync(outputDir, { recursive: true });
const metadata = {
  phase: 'revision-after',
  startingSha: '40969c43004d792c0f18658ccd97fbb632bdb967',
  browser: 'Chromium / SwiftShader',
  captures: [],
  transitions: [],
  consoleErrors: [],
};

(async () => {
  const browser = await qa.launchBrowser();
  try {
    if (process.env.GIM51_SKIP_STATIC !== '1') {
    const desktop = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    desktop.page.on('console', (message) => { if (message.type() === 'error') metadata.consoleErrors.push(message.text()); });
    desktop.page.on('pageerror', (error) => metadata.consoleErrors.push(error.message));
    const cases = [
      { slug: 'rust', zooms: [0.3, 0.6, 1, 3] },
      { slug: 'ownership', zooms: [0.3, 0.6, 1, 3] },
      { slug: 'stack-and-heap', zooms: [0.3, 0.6, 1, 3] },
      { slug: 'operating-systems', zooms: [0.3, 0.6, 1, 3] },
    ];
    for (const entry of cases) {
      await qa.openFocus(desktop.page, entry.slug);
      for (const zoom of entry.zooms) {
        await qa.setZoom(desktop.page, zoom);
        await desktop.page.waitForTimeout(150);
        const snapshot = await qa.getSnapshot(desktop.page);
        const file = `${entry.slug}-k${zoom}-dpr1.png`;
        await desktop.page.screenshot({ path: path.join(outputDir, file) });
        metadata.captures.push({
          name: file, kind: 'desktop-zoom', slug: entry.slug, zoom,
          viewport: snapshot.viewport, canvas: snapshot.canvas,
          productionCanvas: snapshot.productionCanvas, renderer: snapshot.productionCanvas?.renderer,
          reducedMotion: snapshot.reducedMotion, focus: snapshot.scene.focus.slug,
          nodeRadii: snapshot.scene.allNodes.map(({ slug, role, radius, opacity }) => ({ slug, role, radius, opacity })),
          relationshipCount: snapshot.scene.relationships.length,
          sameDisplayedScene: snapshot.sameDisplayedScene,
        });
      }
    }
    await desktop.context.close();
    } else {
      const desktop = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
      const cases = [
        { slug: 'rust', zooms: [0.3, 0.6, 1, 3] },
        { slug: 'ownership', zooms: [0.3, 0.6, 1, 3] },
        { slug: 'stack-and-heap', zooms: [0.3, 0.6, 1, 3] },
        { slug: 'operating-systems', zooms: [0.3, 0.6, 1, 3] },
      ];
      for (const entry of cases) {
        await qa.openFocus(desktop.page, entry.slug);
        for (const zoom of entry.zooms) {
          await qa.setZoom(desktop.page, zoom);
          const snapshot = await qa.getSnapshot(desktop.page);
          const file = `${entry.slug}-k${zoom}-dpr1.png`;
          metadata.captures.push({
            name: file, kind: 'desktop-zoom', slug: entry.slug, zoom,
            viewport: snapshot.viewport, canvas: snapshot.canvas,
            productionCanvas: snapshot.productionCanvas, renderer: snapshot.productionCanvas?.renderer,
            reducedMotion: snapshot.reducedMotion, focus: snapshot.scene.focus.slug,
            nodeRadii: snapshot.scene.allNodes.map(({ slug, role, radius, opacity }) => ({ slug, role, radius, opacity })),
            relationshipCount: snapshot.scene.relationships.length,
            sameDisplayedScene: snapshot.sameDisplayedScene,
          });
        }
      }
      await desktop.context.close();
    }

    const transitionPage = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, slowTransitionClock: true, clockScale: 0.01 });
    transitionPage.page.on('console', (message) => { if (message.type() === 'error') metadata.consoleErrors.push(message.text()); });
    transitionPage.page.on('pageerror', (error) => metadata.consoleErrors.push(error.message));
    await qa.openFocus(transitionPage.page, 'rust');
    const captureTransitionStage = async (progress) => {
      const snapshot = await qa.getSnapshot(transitionPage.page);
      const diagnostics = await qa.getDiagnostics(transitionPage.page);
      const attachment = qa.analyzeAttachments(snapshot, diagnostics.pathCommands, diagnostics.bodyCircles);
      const file = `transition-rust-to-ownership-p${Math.round(progress * 100)}.png`;
      await transitionPage.page.screenshot({ path: path.join(outputDir, file) });
      metadata.transitions.push({
        name: file, from: 'rust', to: 'ownership', requestedProgress: progress,
        actualProgress: progress === 0 ? 0 : snapshot.travel?.progress, active: snapshot.travel?.active,
        sameDisplayedScene: snapshot.sameDisplayedScene,
        attachment,
        focusRole: snapshot.scene.allNodes.find((node) => node.role === 'focus')?.slug,
        nodes: snapshot.scene.allNodes.map(({ slug, role, x, y, radius, opacity }) => ({ slug, role, x, y, radius, opacity })),
        relationshipCount: snapshot.scene.relationships.length,
        viewport: snapshot.viewport,
      });
    };
    await captureTransitionStage(0);
    await transitionPage.page.evaluate(() => {
      const control = document.querySelector('[data-concept-slug="ownership"]');
      const propsKey = Object.keys(control).find((key) => key.startsWith('__reactProps$'));
      control[propsKey].onClick();
    });
    for (const progress of [0.25, 0.5, 0.75]) {
      await qa.waitForProgress(transitionPage.page, progress);
      await captureTransitionStage(progress);
    }
    await transitionPage.page.waitForFunction((expression) => eval(expression)?.travel?.active === false, qa.GRAPH_SNAPSHOT_EXPRESSION, { timeout: 10000 });
    await captureTransitionStage(1);
    await transitionPage.context.close();

    const mobileCases = [
      { name: 'mobile-390x844-dpr3', viewport: { width: 390, height: 844 }, dpr: 3, slug: 'stack-and-heap' },
      { name: 'mobile-320x700-dpr2', viewport: { width: 320, height: 700 }, dpr: 2, slug: 'operating-systems' },
    ];
    for (const entry of mobileCases) {
      const mobile = await qa.createPage(browser, { viewport: entry.viewport, deviceScaleFactor: entry.dpr, isMobile: true, hasTouch: true });
      mobile.page.on('console', (message) => { if (message.type() === 'error') metadata.consoleErrors.push(message.text()); });
      mobile.page.on('pageerror', (error) => metadata.consoleErrors.push(error.message));
      await qa.openFocus(mobile.page, entry.slug);
      await qa.setZoom(mobile.page, 1);
      const snapshot = await qa.getSnapshot(mobile.page);
      const file = `${entry.name}-${entry.slug}.png`;
      await mobile.page.screenshot({ path: path.join(outputDir, file) });
      metadata.captures.push({ name: file, kind: 'mobile', slug: entry.slug, zoom: snapshot.transform.k, viewport: snapshot.viewport, canvas: snapshot.canvas, productionCanvas: snapshot.productionCanvas, reducedMotion: snapshot.reducedMotion, sameDisplayedScene: snapshot.sameDisplayedScene });
      // Exercise pointer pinch handlers on the graph canvas and preserve the resulting snapshot for verification.
      const gesture = await mobile.page.evaluate((expression) => {
        const canvas = [...document.querySelectorAll('canvas')].find((item) => !item.hasAttribute('data-production-celestial-layer'));
        const propsKey = Object.keys(canvas).find((key) => key.startsWith('__reactProps$'));
        const props = canvas[propsKey];
        const rect = canvas.getBoundingClientRect();
        if (typeof props.onTouchStart === 'function' && typeof props.onTouchMove === 'function') {
          props.onTouchStart({ touches: [{ clientX: rect.left + 80, clientY: rect.top + 100 }, { clientX: rect.left + 160, clientY: rect.top + 100 }] });
          props.onTouchMove({ touches: [{ clientX: rect.left + 60, clientY: rect.top + 100 }, { clientX: rect.left + 180, clientY: rect.top + 100 }], preventDefault() {} });
          return { invoked: true, transform: eval(expression).transform };
        }
        return { invoked: false, transform: eval(expression).transform };
      }, qa.GRAPH_SNAPSHOT_EXPRESSION);
      metadata.mobileGesture = (metadata.mobileGesture ?? []).concat([{ viewport: entry.viewport, dpr: entry.dpr, ...gesture }]);
      await mobile.context.close();
    }

    const reduced = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
    await qa.openFocus(reduced.page, 'rust');
    await qa.setZoom(reduced.page, 0.6);
    const reducedSnapshot = await qa.getSnapshot(reduced.page);
    const reducedFile = 'reduced-motion-rust-k0.6-dpr1.png';
    await reduced.page.screenshot({ path: path.join(outputDir, reducedFile) });
    metadata.captures.push({ name: reducedFile, kind: 'reduced-motion', slug: 'rust', zoom: reducedSnapshot.transform.k, viewport: reducedSnapshot.viewport, reducedMotion: reducedSnapshot.reducedMotion, sameDisplayedScene: reducedSnapshot.sameDisplayedScene });
    await reduced.context.close();
  } finally {
    await browser.close();
  }
  fs.writeFileSync('/workspace/gim51-qa/revision-after/metadata.json', JSON.stringify(metadata, null, 2));
  console.log(JSON.stringify({ captures: metadata.captures.length, transitions: metadata.transitions.length, navigationSequence: metadata.navigationSequence, interruptedTransition: metadata.interruptedTransition, mobileGesture: metadata.mobileGesture, consoleErrors: metadata.consoleErrors }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
