const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require("/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

const outputDir = "/workspace/gim51-qa/before";
fs.mkdirSync(outputDir, { recursive: true });

function graphSnapshotExpression() {
  return `(() => {
    const canvas = [...document.querySelectorAll('canvas')].find((item) => !item.hasAttribute('data-production-celestial-layer'));
    if (!canvas) return null;
    const fiberKey = Object.keys(canvas).find((key) => key.startsWith('__reactFiber$'));
    let fiber = fiberKey ? canvas[fiberKey] : null;
    let graph = null;
    while (fiber) {
      const hooks = [];
      for (let hook = fiber.memoizedState; hook; hook = hook.next) hooks.push(hook);
      const sceneRef = hooks.map((hook) => hook.memoizedState).find((state) => state?.current?.allNodes && state.current.relationships);
      const transformRef = hooks.map((hook) => hook.memoizedState).find((state) => state?.current && typeof state.current.k === 'number' && typeof state.current.x === 'number');
      if (sceneRef && transformRef) { graph = { fiber, hooks, sceneRef, transformRef }; break; }
      fiber = fiber.return;
    }
    if (!graph) return null;
    const scene = graph.sceneRef.current;
    const productionCanvas = document.querySelector('[data-production-celestial-layer]');
    let controller = null;
    if (productionCanvas) {
      const productionFiberKey = Object.keys(productionCanvas).find((key) => key.startsWith('__reactFiber$'));
      let productionFiber = productionFiberKey ? productionCanvas[productionFiberKey] : null;
      while (productionFiber && !controller) {
        for (let hook = productionFiber.memoizedState; hook; hook = hook.next) {
          const current = hook.memoizedState?.current;
          if (current && typeof current.getLifecycleStats === 'function') controller = current;
        }
        productionFiber = productionFiber.return;
      }
    }
    return {
      scene,
      transform: graph.transformRef.current,
      controller: controller ? controller.getLifecycleStats() : null,
      canvas: { width: canvas.width, height: canvas.height, rect: canvas.getBoundingClientRect().toJSON() },
      productionCanvas: productionCanvas ? { width: productionCanvas.width, height: productionCanvas.height, hasWebgl2: Boolean(productionCanvas.getContext('webgl2')) } : null,
    };
  })()`;
}

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: "/usr/bin/chromium",
    args: ["--no-sandbox", "--enable-webgl", "--ignore-gpu-blocklist", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const errors = [];
  const metadata = { phase: "before", startingSha: "40969c43004d792c0f18658ccd97fbb632bdb967", browser: "Chromium / SwiftShader", captures: [], consoleErrors: errors };
  try {
    const page = await context.newPage();
    page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
    page.on("pageerror", (error) => errors.push(error.message));
    const cases = [
      { slug: "rust", zooms: [0.3, 0.6, 1, 3] },
      { slug: "ownership", zooms: [0.3, 0.6, 1, 3] },
      { slug: "stack-and-heap", zooms: [0.3, 0.6, 1, 3] },
      { slug: "operating-systems", zooms: [0.3, 0.6, 1, 3] },
    ];
    for (const entry of cases) {
      const route = entry.slug === "rust" ? "/" : `/concept/${entry.slug}`;
      const response = await page.goto(`http://127.0.0.1:3001${route}`, { waitUntil: "networkidle" });
      if (!response || response.status() !== 200) throw new Error(`HTTP ${response?.status()} for ${route}`);
      await page.waitForFunction((expression) => {
        const snapshot = eval(expression);
        return snapshot?.scene?.allNodes?.length > 0 && snapshot?.controller?.rendererAvailable;
      }, graphSnapshotExpression());
      await page.waitForTimeout(450);
      for (const zoom of entry.zooms) {
        await page.evaluate(({ expression, zoom }) => {
          const snapshot = eval(expression);
          if (!snapshot) throw new Error("GraphCanvas hooks unavailable");
          snapshot.transform.k = zoom;
          const canvas = [...document.querySelectorAll("canvas")].find((item) => !item.hasAttribute("data-production-celestial-layer"));
          const propsKey = Object.keys(canvas).find((key) => key.startsWith("__reactProps$"));
          const props = canvas[propsKey];
          const rect = canvas.getBoundingClientRect();
          const event = { clientX: rect.left + 24, clientY: rect.top + 24 };
          props.onMouseDown(event);
          props.onMouseMove(event);
          props.onMouseUp({ clientX: event.clientX + 8, clientY: event.clientY });
        }, { expression: graphSnapshotExpression(), zoom });
        await page.waitForTimeout(120);
        const snapshot = await page.evaluate(graphSnapshotExpression());
        const baseName = `${entry.slug}-k${zoom}-dpr1.png`;
        const file = path.join(outputDir, baseName);
        await page.screenshot({ path: file });
        metadata.captures.push({
          slug: entry.slug,
          zoom,
          path: path.relative("/workspace/gim51-qa", file),
          viewport: { width: 1440, height: 900 },
          devicePixelRatio: await page.evaluate(() => window.devicePixelRatio),
          canvas: snapshot.canvas,
          productionCanvas: snapshot.productionCanvas,
          rendererAvailable: snapshot.controller?.rendererAvailable,
          focus: snapshot.scene.focus.slug,
          nodes: snapshot.scene.allNodes.map(({ slug, role, x, y, radius, opacity }) => ({ slug, role, x, y, radius, opacity })),
          relationshipCount: snapshot.scene.relationships.length,
        });
      }
    }
  } finally {
    await context.close();
    await browser.close();
  }
  fs.writeFileSync("/workspace/gim51-qa/before/metadata.json", JSON.stringify(metadata, null, 2));
  console.log(JSON.stringify({ captures: metadata.captures.length, consoleErrors: errors, files: metadata.captures.map((capture) => capture.path) }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
