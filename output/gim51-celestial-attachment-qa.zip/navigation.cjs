const fs = require('node:fs');
const qa = require('./qa-common.cjs');
const result = {
  label: 'Production browser navigation continuity using Chromium and SwiftShader',
  forwardReverseSequence: [],
  interruptedTransitions: [],
  consoleErrors: [],
};
const sequence = ['ownership','memory','stack-and-heap','operating-systems','cpus','operating-systems','stack-and-heap','memory','ownership','rust'];

async function trigger(page, slug) {
  await page.evaluate((slug) => {
    const control = document.querySelector(`[data-concept-slug="${slug}"]`);
    if (control) {
      const key = Object.keys(control).find((name) => name.startsWith('__reactProps$'));
      control[key]?.onClick?.();
    } else {
      history.pushState({ slug }, '', `/concept/${slug}`);
      dispatchEvent(new PopStateEvent('popstate'));
    }
  }, slug);
  await page.waitForFunction(({ expression, slug }) => {
    const snapshot = eval(expression);
    return location.pathname.endsWith(`/concept/${slug}`) && snapshot?.travel?.active === true && snapshot.travel.toSlug === slug;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, slug }, { timeout: 10000 });
}
async function waitForTarget(page, slug) {
  await page.waitForFunction(({ expression, slug }) => {
    const snapshot = eval(expression);
    return location.pathname.endsWith(`/concept/${slug}`) && snapshot?.scene?.focus?.slug === slug && snapshot?.travel?.active === false && snapshot?.travel?.progress === 1;
  }, { expression: qa.GRAPH_SNAPSHOT_EXPRESSION, slug }, { timeout: 10000 });
}
async function recordMidpoint(page, from, to, index) {
  await trigger(page, to);
  const sample = await qa.waitForProgress(page, 0.5);
  const diagnostics = await qa.getDiagnostics(page);
  const attachment = qa.analyzeAttachments(sample, diagnostics.pathCommands, diagnostics.bodyCircles);
  await waitForTarget(page, to);
  return {
    index, from, to, progress: sample.travel.progress,
    sameDisplayedScene: sample.sameDisplayedScene,
    focus: sample.scene.focus.slug,
    attachment,
  };
}

(async () => {
  const browser = await qa.launchBrowser();
  try {
    const { context, page } = await qa.createPage(browser, { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, slowTransitionClock: true, clockScale: 0.1 });
    page.on('console', (message) => { if (message.type() === 'error') result.consoleErrors.push(message.text()); });
    page.on('pageerror', (error) => result.consoleErrors.push(error.message));
    await qa.openFocus(page, 'rust');
    let from = 'rust';
    for (let index = 0; index < sequence.length; index += 1) {
      const to = sequence[index];
      result.forwardReverseSequence.push(await recordMidpoint(page, from, to, index + 1));
      from = to;
    }

    await trigger(page, 'ownership');
    await qa.waitForProgress(page, 0.5);
    const firstMidpoint = await qa.getSnapshot(page);
    await trigger(page, 'memory');
    const secondMidpoint = await qa.waitForProgress(page, 0.25);
    result.interruptedTransitions.push({
      phase: 'ownership-to-memory-interruption',
      firstTransitionProgress: firstMidpoint.travel.progress,
      replacementTransitionProgress: secondMidpoint.travel.progress,
      replacementTarget: secondMidpoint.travel.toSlug,
      currentFocus: secondMidpoint.scene.focus.slug,
      sameDisplayedScene: secondMidpoint.sameDisplayedScene,
    });

    await trigger(page, 'stack-and-heap');
    const thirdMidpoint = await qa.waitForProgress(page, 0.25);
    result.interruptedTransitions.push({
      phase: 'memory-to-stack-and-heap-interruption',
      replacementTransitionProgress: thirdMidpoint.travel.progress,
      replacementTarget: thirdMidpoint.travel.toSlug,
      currentFocus: thirdMidpoint.scene.focus.slug,
      sameDisplayedScene: thirdMidpoint.sameDisplayedScene,
    });
    await waitForTarget(page, 'stack-and-heap');
    const final = await qa.getSnapshot(page);
    result.finalSnapshot = {
      focus: final.scene.focus.slug,
      transform: final.transform,
      viewport: final.viewport,
      sameDisplayedScene: final.sameDisplayedScene,
    };
    await context.close();
  } finally { await browser.close(); }
  fs.writeFileSync('/workspace/gim51-qa/navigation.json', JSON.stringify(result, null, 2));
  console.log(JSON.stringify({
    sequence: result.forwardReverseSequence.map(({ from, to, progress, sameDisplayedScene, attachment }) => ({ from, to, progress, sameDisplayedScene, attachment })),
    interruptedTransitions: result.interruptedTransitions,
    finalSnapshot: result.finalSnapshot,
    consoleErrors: result.consoleErrors,
  }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
