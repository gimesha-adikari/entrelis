# GIM-51 R2 hit-target follow-up browser evidence

Production build served locally with Next.js 16.3.8 and Chromium 151.0.7922.173. Chromium ran WebGL through SwiftShader (`--enable-unsafe-swiftshader --use-gl=angle --use-angle=swiftshader`). All four cases confirmed a WebGL context was created.

| Viewport (CSS px) | DPR | Zoom | WebGL body radius | Rim + 10px | Outside hit area | Empty space | Keyboard | Canvas backing ratio |
|---|---:|---:|---:|---|---|---|---|---:|
| 1440×900 | 1 | 0.3 | 34 CSS px | /concept/rust | / (46.5 px from center; hit radius 46 px) | / | /concept/ownership | 1× |
| 1440×900 | 2 | 3 | 34 CSS px | /concept/rust | / (46.5 px from center; hit radius 46 px) | / | /concept/ownership | 2× |
| 390×844 | 3 | 0.3 | 24 CSS px | /concept/rust | / (38 px from center; hit radius 36 px) | / | /concept/ownership | 2× |
| 320×700 | 2 | 3 | 24 CSS px | /concept/rust | / (38 px from center; hit radius 36 px) | / | /concept/ownership | 2× |

Zoom extremes were reached with the existing zoom controls (six zoom-out clicks clamp to `k=0.3`; five zoom-in clicks clamp to `k=3`). The disabled control state confirmed each limit. Desktop body centers were projected from `x=-100`; mobile centers from `y=-30`, using the current CSS canvas rectangle.

The mobile miss probe is 2 CSS px beyond the 12px padding boundary because fractional touch coordinates can be quantized to whole CSS pixels. It remained within a few pixels of the intended hit boundary.

The unit regression matrix separately checks exact `k=0.3`, `0.6`, `1`, and `3` across desktop and both mobile sizes at DPR 1, 2, and 3. Canvas fallback tests verify its zoom-scaled target; full tests also retain scene priority and keyboard behavior.

## Screenshots

- `desktop-1440x900-dpr1-k03.png` — capture at the tested zoom and device scale.
- `desktop-1440x900-dpr2-k3.png` — capture at the tested zoom and device scale.
- `mobile-390x844-dpr3-k03.png` — capture at the tested zoom and device scale.
- `mobile-320x700-dpr2-k3.png` — capture at the tested zoom and device scale.

All screenshots are full viewport captures; their pixel dimensions equal CSS viewport × actual browser DPR.

## Automated validation

- Node `v22.13.1`; `npm ci` completed. npm emitted a deprecation notice for the locked `eslint@9.39.5` version.
- `npm run format:check`, `npm run lint`, `npm run typecheck`, `npm run test`, `npm run build`, and `git diff --check` all passed.
- Vitest: 32 files, 286 tests passed. The suite emitted its existing jsdom `HTMLCanvasElement.getContext()` not implemented notices and the Vitest jsdom-environment performance advisory; there were no test failures.
