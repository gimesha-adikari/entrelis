import fs from "node:fs/promises";
import path from "node:path";
import playwright from "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.js";

const { chromium } = playwright;

const outputDir = "/workspace/gim51-qa/hit-target-browser";
await fs.mkdir(outputDir, { recursive: true });

const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox", "--enable-unsafe-swiftshader", "--use-gl=angle", "--use-angle=swiftshader"],
});

const cases = [
  { name: "desktop-1440x900-dpr1-k03", width: 1440, height: 900, dpr: 1, mobile: false, zoom: 0.3 },
  { name: "desktop-1440x900-dpr2-k3", width: 1440, height: 900, dpr: 2, mobile: false, zoom: 3 },
  { name: "mobile-390x844-dpr3-k03", width: 390, height: 844, dpr: 3, mobile: true, zoom: 0.3 },
  { name: "mobile-320x700-dpr2-k3", width: 320, height: 700, dpr: 2, mobile: true, zoom: 3 },
];

const results = [];

async function openCase(testCase) {
  const context = await browser.newContext({
    viewport: { width: testCase.width, height: testCase.height },
    deviceScaleFactor: testCase.dpr,
    isMobile: testCase.mobile,
    hasTouch: testCase.mobile,
  });
  const page = await context.newPage();
  await page.addInitScript(() => {
    const originalGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, ...args) {
      const result = originalGetContext.call(this, type, ...args);
      if (typeof type === "string" && type.startsWith("webgl") && result) {
        window.__productionWebglCreated = true;
      }
      return result;
    };
  });
  await page.goto("http://127.0.0.1:3000/", { waitUntil: "networkidle" });
  await page.waitForFunction(() => window.__productionWebglCreated === true, undefined, {
    timeout: 15000,
  });
  await page.waitForTimeout(250);
  return { context, page };
}

async function getCanvasMetrics(page) {
  return page.locator('canvas[aria-hidden="true"]:not([data-production-celestial-layer])').evaluate((canvas) => {
    const rect = canvas.getBoundingClientRect();
    return {
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
      backingWidth: canvas.width,
      backingHeight: canvas.height,
      devicePixelRatio: window.devicePixelRatio,
      rendererAvailable: window.__productionWebglCreated === true,
    };
  });
}

async function setZoom(page, rect, target) {
  const selector = page.getByRole("button", { name: target < 1 ? "Zoom out" : "Zoom in" });
  const clicks = target < 1 ? 6 : 5;
  for (let index = 0; index < clicks; index += 1) {
    await selector.click();
  }
  await page.waitForTimeout(50);
  const state = await page.evaluate(() => ({
    zoomOutDisabled: document.querySelector('[aria-label="Zoom out"]').disabled,
    zoomInDisabled: document.querySelector('[aria-label="Zoom in"]').disabled,
  }));
  if (target < 1 ? !state.zoomOutDisabled : !state.zoomInDisabled) {
    throw new Error(`Zoom controls did not reach the requested ${target} extreme: ${JSON.stringify(state)}`);
  }
  return state;
}

async function clickAt(page, mobile, x, y) {
  if (mobile) {
    await page.touchscreen.tap(x, y);
  } else {
    await page.mouse.click(x, y);
  }
}

for (const testCase of cases) {
  const { context, page } = await openCase(testCase);
  const metrics = await getCanvasMetrics(page);
  const bodyRadius = testCase.mobile ? 24 : 34;
  const bodyWorldX = testCase.mobile ? 0 : -100;
  const bodyWorldY = testCase.mobile ? -30 : 0;
  const bodyCssX = metrics.left + metrics.width / 2 + bodyWorldX * testCase.zoom;
  const bodyCssY = metrics.top + metrics.height / 2 + bodyWorldY * testCase.zoom;

  const zoomControlState = await setZoom(page, metrics, testCase.zoom);
  await page.screenshot({ path: path.join(outputDir, `${testCase.name}.png`), fullPage: true });
  await clickAt(page, testCase.mobile, bodyCssX, bodyCssY - bodyRadius - 10);
  await page.waitForTimeout(80);
  const rimPlusPaddingPath = new URL(page.url()).pathname;
  if (rimPlusPaddingPath !== "/concept/rust") {
    throw new Error(`${testCase.name}: the visible body rim plus 10px padding was not clickable`);
  }

  await page.evaluate(() => window.history.replaceState({}, "", "/"));
  // Touch input can quantize fractional client coordinates to whole CSS pixels.
  const outsidePaddingExtra = testCase.mobile ? 14 : 12.5;
  const outsideX =
    metrics.left + metrics.width / 2 + bodyWorldX * testCase.zoom;
  const outsideY =
    metrics.top +
    metrics.height / 2 +
    bodyWorldY * testCase.zoom -
    bodyRadius -
    outsidePaddingExtra;
  await clickAt(page, testCase.mobile, outsideX, outsideY);
  await page.waitForTimeout(80);
  const outsidePaddingPath = new URL(page.url()).pathname;
  if (outsidePaddingPath !== "/") {
    throw new Error(`${testCase.name}: click outside the CSS hit padding selected ${outsidePaddingPath}`);
  }

  await page.evaluate(() => window.history.replaceState({}, "", "/"));
  const emptyOffset = Math.min(260, metrics.width / 2 - 24);
  const emptyX = metrics.left + metrics.width / 2 + emptyOffset;
  const emptyY = metrics.top + metrics.height / 2;
  await clickAt(page, testCase.mobile, emptyX, emptyY);
  await page.waitForTimeout(80);
  const emptySpacePath = new URL(page.url()).pathname;
  if (emptySpacePath !== "/") {
    throw new Error(`${testCase.name}: clearly empty-space click selected ${emptySpacePath}`);
  }

  await page.getByTestId("concept-accessible-control-concept-ownership").focus();
  await page.keyboard.press("Enter");
  await page.waitForFunction(() => window.location.pathname === "/concept/ownership", undefined, {
    timeout: 4000,
  });
  const keyboardNavigationPath = new URL(page.url()).pathname;

  results.push({
    ...testCase,
    canvas: metrics,
    zoomControlState,
    projectedBodyCenterCss: { x: bodyCssX, y: bodyCssY },
    expectedBodyRadiusCss: bodyRadius,
    observedClicks: {
      visibleRimPlus10px: {
        offsetCss: bodyRadius + 10,
        vectorCss: { x: 0, y: -(bodyRadius + 10) },
        path: rimPlusPaddingPath,
      },
      outside12pxPadding: {
        offsetCss: bodyRadius + outsidePaddingExtra,
        intendedHitRadiusCss: Math.max(bodyRadius + 12, 24),
        vectorCss: { x: 0, y: -(bodyRadius + outsidePaddingExtra) },
        path: outsidePaddingPath,
      },
      emptySpace: { offsetCss: emptyOffset, path: emptySpacePath },
      keyboardOwnership: keyboardNavigationPath,
    },
  });

  await context.close();
}

await fs.writeFile(path.join(outputDir, "results.json"), JSON.stringify(results, null, 2));
await browser.close();
console.log(JSON.stringify(results, null, 2));
